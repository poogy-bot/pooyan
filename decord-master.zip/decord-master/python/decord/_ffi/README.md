# C API and runtime FFI module

Borrowed and adapted from dmlc TVM/DGL projects.
