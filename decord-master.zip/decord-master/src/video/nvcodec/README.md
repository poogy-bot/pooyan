# GPU accelerated decoding through nvdec

Require CUDA Driver and toolkit >= 8.0 and a supported graphic card.

