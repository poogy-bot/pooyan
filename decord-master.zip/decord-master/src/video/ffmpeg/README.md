# Decoding through FFMPEG

Require FFMPEG >= 4.0

## List of components

- Libavcodec
- Libavfilter
- Libavformat