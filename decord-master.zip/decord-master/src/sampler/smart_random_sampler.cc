/*!
 *  Copyright (c) 2019 by Contributors if not otherwise specified
 * \file smart_random_sampler.cc
 * \brief Smart random sampler for faster video random access
 */

#include "smart_random_sampler.h"

namespace decord {
namespace sampler {

}  // sampler
}  // decord
