# Algorithms for cutting clips by scene contents/fixed intervals, etc.
